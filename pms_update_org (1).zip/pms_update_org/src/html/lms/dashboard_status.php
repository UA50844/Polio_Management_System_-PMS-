
                                
                                <?php

include 'connect.php';
// $products_data = $conn->prepare("SELECT * FROM products_data");
// $products_data->execute();
// $products_data_result = $products_data->fetchAll(PDO::FETCH_BOTH);
// $total_products = count($products_data_result);


// $vendor_query = $conn->prepare("SELECT * FROM vendor_data");
// $vendor_query->execute();
// $vendor_result = $vendor_query->fetchAll(PDO::FETCH_BOTH);
// $total_vendor = count($vendor_result);

// // Query for brand
// $brand_query = $conn->prepare("SELECT * FROM brands");
// $brand_query->execute();
// $brand_result = $brand_query->fetchAll(PDO::FETCH_BOTH);
// $total_brand = count($brand_result);




// Function to get total users by role
function getTotalUsersByRole($conn, $role) {
    $query = $conn->prepare("SELECT * FROM users WHERE role = :role");
    $query->bindParam(':role', $role);
    $query->execute();
    $result = $query->fetchAll(PDO::FETCH_BOTH);
    return count($result);
}

// Usage example:
$total_officer = getTotalUsersByRole($conn, 'officer');
$total_worker = getTotalUsersByRole($conn, 'worker');
$total_supervisor = getTotalUsersByRole($conn, 'supervisor');








$public_data = $conn->prepare("SELECT * FROM public_data");
$public_data->execute();
$public_data_result = $public_data->fetchAll(PDO::FETCH_BOTH);
$total_public_data = count($public_data_result);


$public_member = $conn->prepare("SELECT * FROM public_member");
$public_member->execute();
$public_member_result = $public_member->fetchAll(PDO::FETCH_BOTH);
$total_public_member = count($public_member_result);



$telesheet_data = $conn->prepare("SELECT * FROM telesheet_data");
$telesheet_data->execute();
$telesheet_data_result = $telesheet_data->fetchAll(PDO::FETCH_BOTH);
$total_telesheet_data = count($telesheet_data_result);



$telesheet_entry = $conn->prepare("SELECT * FROM telesheet_entry");
$telesheet_entry->execute();
$telesheet_entry_result = $telesheet_entry->fetchAll(PDO::FETCH_BOTH);
$total_telesheet_entry = count($telesheet_entry_result);

$lockhouse_entry = $conn->prepare("SELECT * FROM lockhouse_entry");
$lockhouse_entry->execute();
$lockhouse_entry_result = $lockhouse_entry->fetchAll(PDO::FETCH_BOTH);
$total_lockhouse_entry = count($lockhouse_entry_result);


$lockhouse_data = $conn->prepare("SELECT * FROM lockhouse_data");
$lockhouse_data->execute();
$lockhouse_data_result = $lockhouse_data->fetchAll(PDO::FETCH_BOTH);
$total_lockhouse_data = count($lockhouse_data_result);


$nar_list_data = $conn->prepare("SELECT * FROM nar_list_data");
$nar_list_data->execute();
$nar_list_data_result = $nar_list_data->fetchAll(PDO::FETCH_BOTH);
$total_nar_list_data = count($nar_list_data_result);


$nar_list_entry = $conn->prepare("SELECT * FROM nar_list_entry");
$nar_list_entry->execute();
$nar_list_entry_result = $nar_list_entry->fetchAll(PDO::FETCH_BOTH);
$total_nar_list_entry = count($nar_list_entry_result);


$nar_list_guest_entry = $conn->prepare("SELECT * FROM nar_list_guest_entry");
$nar_list_guest_entry->execute();
$nar_list_guest_entry_result = $nar_list_guest_entry->fetchAll(PDO::FETCH_BOTH);
$total_nar_list_guest_entry = count($nar_list_guest_entry_result);



$equipment_list = $conn->prepare("SELECT * FROM telesheet_data");
$equipment_list->execute();
$equipment_list_result = $equipment_list->fetchAll(PDO::FETCH_BOTH);
$total_equipment_list = count($equipment_list_result);


$immediate_fever_weakness_list = $conn->prepare("SELECT * FROM immediate_fever_weakness_list");
$immediate_fever_weakness_list->execute();
$immediate_fever_weakness_list_result = $immediate_fever_weakness_list->fetchAll(PDO::FETCH_BOTH);
$total_immediate_fever_weakness_list = count($immediate_fever_weakness_list_result);

$unimmunized_list = $conn->prepare("SELECT * FROM unimmunized_list");
$unimmunized_list->execute();
$unimmunized_list_result = $unimmunized_list->fetchAll(PDO::FETCH_BOTH);
$total_unimmunized_list = count($unimmunized_list_result);


$housechalking_data = $conn->prepare("SELECT * FROM housechalking_data");
$housechalking_data->execute();
$housechalking_data_result = $housechalking_data->fetchAll(PDO::FETCH_BOTH);
$total_housechalking_data = count($housechalking_data_result);


$housechalking_entry = $conn->prepare("SELECT * FROM housechalking_entry");
$housechalking_entry->execute();
$housechalking_entry_result = $housechalking_entry->fetchAll(PDO::FETCH_BOTH);
$total_housechalking_entry = count($housechalking_entry_result);


$micro_plan = $conn->prepare("SELECT * FROM microplan_data");
$micro_plan->execute();
$micro_plan_result = $micro_plan->fetchAll(PDO::FETCH_BOTH);
$total_micro_plan = count($micro_plan_result);

//   // Query for categories
//       // Query for categories
//       $category_query = $conn->prepare("SELECT DISTINCT * FROM categorys");
//       $category_query->execute();
//       $categories = $category_query->fetchAll(PDO::FETCH_COLUMN);
  
//       // Initialize an associative array to store totals
//       $totals = array();
  
//       // Loop through each category
//       foreach ($categories as $category) {
//           // Query for total products in this category
//           $products_query = $conn->prepare("SELECT COUNT(*) AS total_products FROM categorys WHERE category = 'Product'");
//           $products_query->execute();
//           $total_products = $products_query->fetchColumn();
  
//           // Query for total suppliers in this category
//           $suppliers_query = $conn->prepare("SELECT COUNT(*) AS total_suppliers FROM categorys WHERE  category = 'Supplier'");
//           $suppliers_query->execute();
//           $total_suppliers = $suppliers_query->fetchColumn();
  
//           // Query for total vendors in this category
//           $vendors_query = $conn->prepare("SELECT COUNT(*) AS total_vendors FROM categorys WHERE  category = 'Vendor'");
//           $vendors_query->execute();
//           $total_vendors = $vendors_query->fetchColumn();
  
//           // Query for total investors in this category
//           $investors_query = $conn->prepare("SELECT COUNT(*) AS total_investors FROM categorys WHERE  category = 'Investor'");
//           $investors_query->execute();
//           $total_investors = $investors_query->fetchColumn();
  
//           // Store totals in the associative array
//           $totals[$category] = array(
//               'total_products' => $total_products,
//               'total_suppliers' => $total_suppliers,
//               'total_vendors' => $total_vendors,
//               'total_investors' => $total_investors
//           );
  
//           // Output the results for each category
//           $results_categorys = "Products: " . $total_products . "<br>" .
//           "Suppliers: " . $total_suppliers . "<br>" .
//           "Vendors: " . $total_vendors . "<br>" .
//           "Investors: " . $total_investors . "<br><br>";
//       }





//       $invoice_data = $conn->prepare("SELECT * FROM all_invoice_data");
//       $invoice_data->execute();
//       $invoice_data_result = $invoice_data->fetchAll(PDO::FETCH_BOTH);
//       $total_invoice = count($invoice_data_result);
//       $customer_count = 0; 
//       $vendor_count = 0; 

//       $customer_advance_total = 0;
//       $customer_balance_total = 0;
//       $vendor_advance_total = 0;
//       $vendor_balance_total = 0;
//       $per_cus_inv = 0;
//       $per_cus_adv_inv = 0;
//       $per_ven_inv = 0;
//       $per_ven_adv_inv = 0; 


// $sum1 = $sum2 = $sum3 = $sum4 = $sum5 = $sum6 =$sum7 =$sum8 = $sum9 = 0 ;
  
// if(count($invoice_data_result)){

//     foreach($invoice_data_result as $print_invoice){

         

//         if($print_invoice['forinvoice']=='customer'){

    
//         $customer_count++;
//         $sum1 +=intval($print_invoice['advance']);
//        $customer_advance_total = $sum1;


//         $sum2 +=intval($print_invoice['balance']);
//         $customer_balance_total = $sum2;

//        }


//        if($print_invoice['forinvoice']=='vendor'){

//         $vendor_count++;
//         $sum3 +=intval($print_invoice['advance']);
//         $vendor_advance_total = $sum3;


//         $sum4 +=intval($print_invoice['balance']);
//         $vendor_balance_total= $sum4;

//        }
       

//     }}


//     function calculatePercentage($numerator, $denominator) {
//         if ($denominator != 0) {
//             return number_format(($numerator / $denominator) * 100, 2);
//         } else {
//             return 0; // or any default value you prefer
//         }
//     }
    
//     $per_cus_inv = calculatePercentage($customer_count, $total_invoice);
//     $per_ven_inv = calculatePercentage($vendor_count, $total_invoice);
//     $per_cus_adv_inv = calculatePercentage($customer_advance_total, $customer_balance_total);
//     $per_ven_adv_inv = calculatePercentage($vendor_advance_total, $vendor_balance_total);
    
    


   



// if(count($resulted)){

//     foreach($resulted as $print_c){


//         $sum1 +=$print_c['new'];
//         $ccc1 = $sum1;

        // $sum2 +=$print_c['paid'];
        // $ccc2 = $sum2;
        
        // $sum3 +=$print_c['unpaid'];
        // $ccc3 = $sum3;
        
        // $sum4 +=$print_c['followup'];
        // $ccc4 = $sum4;
        
        // $sum5 +=$print_c['interested'];
        // $ccc5 = $sum5;
        
        // $sum6 +=$print_c['no_interested'];
        // $ccc6 = $sum6;
        
        // $sum7 +=$print_c['invalid'];
        // $ccc7 = $sum7;
        
        // $sum8 +=$print_c['no_response'];
        // $ccc8 = $sum8;
        
        // $sum9 +=$print_c['totallead'];
        // $ccc9 = $sum9;



    // }}




    // $totalnew = $ccc1;
    // $totalpaid = $ccc2;
    // $totalunpaid = $ccc3;
    // $totalfollowup = $ccc4;
    // $totalinterested = $ccc5;
    // $totalnointerested = $ccc6;
    // $totalinvalid = $ccc7;
    // $totalnoresponse = $ccc8;
    // $totalllead = $ccc9;

    // $overallperleads = $ccc14;



    // percentage leads





    // $peroverallleads = number_format((($totalllead / $overallperleads)*100) , 2 );

    // $pernewleads = number_format((($totalnew / $totalllead)*100) , 2 );
    // $perpaidleads = number_format((($totalpaid / $totalllead)*100) , 2 );
    // $perunpaidleads = number_format((($totalunpaid / $totalllead)*100) , 2 );
    // $perfollowupleads = number_format((($totalfollowup / $totalllead)*100) , 2 );
    // $perinvalidleads = number_format((($totalinvalid / $totalllead)*100) , 2 );
    // $pernoresponseleads = number_format((($totalnoresponse / $totalllead)*100) , 2 );
    // $pernointleads = number_format((($totalnointerested / $totalllead)*100) , 2 );
    // $perintleads = number_format((($totalinterested / $totalllead)*100) , 2 );




?>
