<?php


include 'header.php';
?>                <!-- main header @e -->
                <!-- content @s -->
           <div class="nk-content ">
                    <div class="container-fluid">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">





<?php
include 'dashboard_status.php';
?>




                                <div class="nk-block-head nk-block-head-sm">
                                    <div class="nk-block-between">
                                        <div class="nk-block-head-content">




                                            <h3 class="nk-block-title page-title">Dashboard</h3>


















                                        </div><!-- .nk-block-head-content -->
                                        <div class="nk-block-head-content">
                                            <!-- <div class="toggle-wrap nk-block-tools-toggle">
                                                <a href="html/under_const/index.html" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                                                <div class="toggle-expand-content" data-content="pageMenu">
                                                    <ul class="nk-block-tools g-3">
                                                        <li>
                                                            <div class="drodown">
                                                                <a href="html/under_const/index.html" class="dropdown-toggle btn btn-white btn-dim btn-outline-light" data-bs-toggle="dropdown"><em class="d-none d-sm-inline icon ni ni-calender-date"></em><span><span class="d-none d-md-inline">Last</span> 30 Days</span><em class="dd-indc icon ni ni-chevron-right"></em></a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <ul class="link-list-opt no-bdr">
                                                                        <li><a href="html/under_const/index.html"><span>Last 30 Days</span></a></li>
                                                                        <li><a href="html/under_const/index.html"><span>Last 6 Months</span></a></li>
                                                                        <li><a href="html/under_const/index.html"><span>Last 1 Years</span></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="nk-block-tools-opt"><a href="html/under_const/index.html" class="btn btn-primary"><em class="icon ni ni-reports"></em><span>Reports</span></a></li>
                                                    </ul>
                                                </div>
                                            </div> -->
                                        </div><!-- .nk-block-head-content -->
                                    </div><!-- .nk-block-between -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                    <div class="row g-gs">
                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Total Officers</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_officer;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-user h2 text-dark"></em>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->




                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Total Supervisor</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_supervisor;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-users h2 p-1"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->


                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Total Worker</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_worker;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-users h2 p-1"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Home Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_public_data;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-home h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->



                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Children Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_public_member;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-users-fill h2 text-primary"></em>
                                                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                      
                                      


                                        

                                        <div class=" col-sm-2">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Micro Plans</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_micro_plan;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file h2 text-primary"></em>
                                                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                     



                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Telesheet Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_telesheet_data;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->
                                      


                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Telesheet Entries</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_telesheet_entry;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->

                                   




                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">Lockhouse Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_lockhouse_data;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->


                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">House Chalking Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_housechalking_data;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->



                                        







                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">House Chalking Entries</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_housechalking_entry;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->







                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">NA/R List Records</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_nar_list_data;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->






                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">NA/R List Entries</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_nar_list_entry;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->





                                        <div class=" col-sm-3">
                                            <div class="card">
                                                <div class="nk-ecwg nk-ecwg6">
                                                    <div class="card-inner">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h6 class="title">NA/R List Guest Entries</h6>
                                                            </div>
                                                        </div>
                                                        <div class="data">
                                                            <div class="data-group">
                                                                <div class="amount"><?php echo $total_nar_list_guest_entry;?></div>
                                                                <div class="nk-ecwg6-ck">
                                                                <em class="icon ni ni-file-docs h2 text-primary"></em>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .card-inner -->
                                                </div><!-- .nk-ecwg -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->




<div class="col-md-8">
                                            <div class="card h-100">
                                                <div class="card-inner mb-n2">
                                                    <div class="card-title-group">
                                                        <div class="card-title card-title-sm">
                                                            <h6 class="title">Vaccine Details</h6>
                                                        </div>
                                                        <div class="card-tools">
                                                            <div class="drodown">
                                                                <a href="#" class="dropdown-toggle dropdown-indicator btn btn-sm btn-outline-light btn-white" data-bs-toggle="dropdown">30 Days</a>
                                                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                                                    <ul class="link-list-opt no-bdr">
                                                                        <li><a href="#"><span>7 Days</span></a></li>
                                                                        <li><a href="#"><span>15 Days</span></a></li>
                                                                        <li><a href="#"><span>30 Days</span></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="nk-tb-list is-loose">
                                                    <div class="nk-tb-item nk-tb-head">
                                                        <div class="nk-tb-col"><span></span></div>
                                                        <div class="nk-tb-col text-end"><span>Used</span></div>
                                                        <div class="nk-tb-col"><span>%</span></div>

                                                        <div class="nk-tb-col tb-col-sm text-end"><span>Remain</span></div>
                                                        <div class="nk-tb-col"><span>%</span></div>
                                                    </div><!-- .nk-tb-head -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-primary icon ni ni-globe"></em>
                                                                <span class="tb-lead">OPV </span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>1,641</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="72.84"></div>
                                                                <div class="progress-amount">72.84%</div>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>1,641</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="72.84"></div>
                                                                <div class="progress-amount">72.84%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-danger icon ni ni-globe"></em>
                                                                <span class="tb-lead">Blue V-A Capsule</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>497</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="7.93"></div>
                                                                <div class="progress-amount">7.93%</div>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>1,641</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="72.84"></div>
                                                                <div class="progress-amount">72.84%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-info icon ni ni-globe"></em>
                                                                <span class="tb-lead">Red V-A Capsule</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>187</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="4.87"></div>
                                                                <div class="progress-amount">4.87%</div>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>1,641</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="72.84"></div>
                                                                <div class="progress-amount">72.84%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                    <div class="nk-tb-item">
                                                        <div class="nk-tb-col">
                                                            <div class="icon-text">
                                                                <em class="text-orange icon ni ni-globe"></em>
                                                                <span class="tb-lead">Finger Marker</span>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>96</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="2.46"></div>
                                                                <div class="progress-amount">2.46%</div>
                                                            </div>
                                                        </div>
                                                        <div class="nk-tb-col text-end">
                                                            <span class="tb-sub tb-amount"><span>1,641</span></span>
                                                        </div>
                                                        <div class="nk-tb-col">
                                                            <div class="progress progress-md progress-alt bg-transparent">
                                                                <div class="progress-bar" data-progress="72.84"></div>
                                                                <div class="progress-amount">72.84%</div>
                                                            </div>
                                                        </div>
                                                    </div><!-- .nk-tb-item -->
                                                  
                                                </div><!-- .nk-tb-list -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->






                                        <div class="col-xxl-3 col-md-4">
                                            <div class="card h-100">
                                                <div class="card-inner">
                                                    <div class="card-title-group mb-2">
                                                        <div class="card-title">
                                                            <h6 class="title">Medicine Records</h6>
                                                        </div>
                                                    </div>
                                                    <ul class="nk-store-statistics">
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Equipment List</div>
                                                                <div class="count"><?php echo $total_nar_list_guest_entry;?></div>
                                                            </div>
                                                            <em class="icon bg-primary-dim ni ni-bag"></em>
                                                        </li>
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Unimmunized List</div>
                                                                <div class="count"><?php echo $total_unimmunized_list;?></div>
                                                            </div>
                                                            <em class="icon bg-info-dim ni ni-users"></em>
                                                        </li>
                                                        <li class="item">
                                                            <div class="info">
                                                                <div class="title">Immediate Fever Weakness List</div>
                                                                <div class="count"><?php echo $total_immediate_fever_weakness_list;?></div>
                                                            </div>
                                                            <em class="icon bg-pink-dim ni ni-box"></em>
                                                        </li>
                                                       
                                                    </ul>
                                                </div><!-- .card-inner -->
                                            </div><!-- .card -->
                                        </div><!-- .col -->




                                       
                                       
                                    </div><!-- .row -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content @e -->
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2023 Qadritiles. Developed by <a href="https://qadritiles.com/" target="_blank">Qadri Tiles.</a>
                            </div>
                            <div class="nk-footer-links">
                                <ul class="nav nav-sm">
                                    <li class="nav-item dropup">
                                        <a href="html/under_const/index.html" class="dropdown-toggle dropdown-indicator has-indicator nav-link text-base" data-bs-toggle="dropdown" data-offset="0,10"><span>English</span></a>
                                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                            <ul class="language-list">
                                                <li>
                                                    <a href="html/under_const/index.html" class="language-item">
                                                        <span class="language-name">English</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="html/under_const/index.html" class="language-item">
                                                        <span class="language-name">Español</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="html/under_const/index.html" class="language-item">
                                                        <span class="language-name">Français</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="html/under_const/index.html" class="language-item">
                                                        <span class="language-name">Türkçe</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="nav-item">
                                        <a data-bs-toggle="modal" href="#region" class="nav-link"><em class="icon ni ni-globe text-"></em><span class="ms-1">Select Region</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- select region modal -->
    <div class="modal fade" tabindex="-1" role="dialog" id="region">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <a href="html/under_const/index.html" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                <div class="modal-body modal-body-md">
                    <h5 class="title mb-4">Select Your Country</h5>
                    <div class="nk-country-region">
                        <ul class="country-list text-center gy-2">
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/arg.png" alt="" class="country-flag">
                                    <span class="country-name">Argentina</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/aus.png" alt="" class="country-flag">
                                    <span class="country-name">Australia</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/bangladesh.png" alt="" class="country-flag">
                                    <span class="country-name">Bangladesh</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/canada.png" alt="" class="country-flag">
                                    <span class="country-name">Canada <small>(English)</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">Centrafricaine</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/china.png" alt="" class="country-flag">
                                    <span class="country-name">China</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/french.png" alt="" class="country-flag">
                                    <span class="country-name">France</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/germany.png" alt="" class="country-flag">
                                    <span class="country-name">Germany</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/iran.png" alt="" class="country-flag">
                                    <span class="country-name">Iran</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/italy.png" alt="" class="country-flag">
                                    <span class="country-name">Italy</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/mexico.png" alt="" class="country-flag">
                                    <span class="country-name">México</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/philipine.png" alt="" class="country-flag">
                                    <span class="country-name">Philippines</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/portugal.png" alt="" class="country-flag">
                                    <span class="country-name">Portugal</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/s-africa.png" alt="" class="country-flag">
                                    <span class="country-name">South Africa</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/spanish.png" alt="" class="country-flag">
                                    <span class="country-name">Spain</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/switzerland.png" alt="" class="country-flag">
                                    <span class="country-name">Switzerland</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/uk.png" alt="" class="country-flag">
                                    <span class="country-name">United Kingdom</span>
                                </a>
                            </li>
                            <li>
                                <a href="html/under_const/index.html" class="country-item">
                                    <img src="./images/flags/english.png" alt="" class="country-flag">
                                    <span class="country-name">United State</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div><!-- .modal-content -->
        </div><!-- .modla-dialog -->
    </div><!-- .modal -->

    <!-- JavaScript -->
    <script src="./assets/js/bundle.js?ver=3.0.3"></script>
    <script src="./assets/js/scripts.js?ver=3.0.3"></script><script src="html/lms/datetime.js"></script>
        <script src="./assets/js/charts/chart-ecommerce.js?ver=3.0.3"></script>
        <script src="./assets/js/charts/chart-analytics.js?ver=3.0.3"></script>
    <script src="./assets/js/example-sweetalert.js?ver=3.0.3"></script>
    <script>


    </script>










</body>

</html>