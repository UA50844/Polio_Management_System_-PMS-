<?php
include 'connect.php';
if ($_POST["getID"]) {
    $getID = $_POST['getID'];
    $query = "select * from user_asign where from_id = '191'";
    $result = mysqli_query($sq_conn, $query);
    if ($result->num_rows > 0) {
        echo '<option value="">Select State</option>';
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<option value="' . $row['id'] . '">' . $row['to_id'] . '</option>';
        }
    }
}
?>